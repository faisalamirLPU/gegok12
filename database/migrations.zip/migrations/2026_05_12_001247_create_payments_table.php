<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {

            $table->id();

            $table->foreignId('school_id');

            $table->foreignId('academic_year_id');

            $table->foreignId('fee_id');

            $table->foreignId('user_id');

            $table->string('receipt_no')->unique();

            $table->decimal('amount', 12, 2);

            $table->string('payment_method');

            $table->string('transaction_id')->nullable();

            $table->text('remarks')->nullable();

            $table->date('payment_date');

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
