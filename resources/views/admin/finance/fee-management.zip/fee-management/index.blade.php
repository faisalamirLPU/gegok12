@extends('layouts.admin.layout')

@section('title', 'Fee Management Dashboard')

@section('content')

<div class="max-w-7xl mx-auto px-4 py-6">

    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Fee Management</h1>
        <p class="text-gray-600">Manage all financial operations for {{ $academicYear->name }}</p>
    </div>

    <!-- Navigation Tabs -->
    <div class="mb-6 border-b border-gray-200">
        <div class="flex flex-wrap gap-4">
            <a href="{{ route('finance.fee-management.index') }}" class="px-4 py-3 border-b-2 border-blue-600 text-blue-600 font-semibold">Dashboard</a>
            <a href="{{ route('finance.fee-management.categories') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Categories</a>
            <a href="{{ route('finance.fee-management.structures') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Structures</a>
            <a href="{{ route('finance.fee-management.special-fees') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Special Fees</a>
            <a href="{{ route('finance.fee-management.payments') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Payments</a>
            <a href="{{ route('finance.fee-management.analytics') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Analytics</a>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">

        <!-- Categories Card -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">Fee Categories</p>
                    <p class="text-3xl font-bold text-gray-800">{{ $stats['active_categories'] }}/{{ $stats['total_categories'] }}</p>
                </div>
                <div class="text-blue-500 text-3xl">📋</div>
            </div>
        </div>

        <!-- Structures Card -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">Fee Structures</p>
                    <p class="text-3xl font-bold text-gray-800">{{ $stats['total_structures'] }}</p>
                </div>
                <div class="text-green-500 text-3xl">📊</div>
            </div>
        </div>

        <!-- Special Fees Card -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">Special Fees</p>
                    <p class="text-3xl font-bold text-gray-800">{{ $stats['total_special_fees'] }}</p>
                </div>
                <div class="text-purple-500 text-3xl">⚡</div>
            </div>
        </div>

        <!-- Pending Payments Card -->
        <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-red-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">Pending Payments</p>
                    <p class="text-3xl font-bold text-gray-800">{{ $stats['pending_payments'] }}</p>
                </div>
                <div class="text-red-500 text-3xl">💳</div>
            </div>
        </div>
    </div>

    <!-- Financial Summary -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">

        <!-- Collected Amount -->
        <div class="bg-gradient-to-br from-green-400 to-green-600 rounded-lg shadow-lg p-6 text-white">
            <p class="text-green-100 text-sm font-semibold mb-1">Collected Amount</p>
            <p class="text-4xl font-bold mb-2">₹{{ number_format($stats['collected_amount'], 2) }}</p>
            <div class="text-green-100 text-xs">From paid fees</div>
        </div>

        <!-- Pending Amount -->
        <div class="bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg shadow-lg p-6 text-white">
            <p class="text-orange-100 text-sm font-semibold mb-1">Pending Amount</p>
            <p class="text-4xl font-bold mb-2">₹{{ number_format($stats['pending_amount'], 2) }}</p>
            <div class="text-orange-100 text-xs">Awaiting collection</div>
        </div>

        <!-- Total Amount -->
        <div class="bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg shadow-lg p-6 text-white">
            <p class="text-blue-100 text-sm font-semibold mb-1">Total Amount</p>
            <p class="text-4xl font-bold mb-2">₹{{ number_format($stats['collected_amount'] + $stats['pending_amount'], 2) }}</p>
            <div class="text-blue-100 text-xs">All fees combined</div>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">

        <!-- Recent Fees -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="bg-gray-50 px-6 py-4 border-b">
                <h3 class="text-lg font-bold text-gray-800">Recent Fee Invoices</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Invoice</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Student</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($recentFees as $fee)
                            <tr class="border-t hover:bg-gray-50">
                                <td class="px-6 py-3 text-sm">{{ $fee->invoice_no }}</td>
                                <td class="px-6 py-3 text-sm">
                                    {{ optional($fee->student->userprofile)->firstname }}
                                    {{ optional($fee->student->userprofile)->lastname }}
                                </td>
                                <td class="px-6 py-3 text-sm font-semibold">₹{{ number_format($fee->total_amount, 2) }}</td>
                                <td class="px-6 py-3 text-sm">
                                    <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $fee->payment_status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                                        {{ ucfirst($fee->payment_status) }}
                                    </span>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="px-6 py-4 text-center text-gray-500">No recent fees</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Special Fees -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="bg-gray-50 px-6 py-4 border-b">
                <h3 class="text-lg font-bold text-gray-800">Recent Special Fees</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Student</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Category</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700">Due Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($recentSpecialFees as $special)
                            <tr class="border-t hover:bg-gray-50">
                                <td class="px-6 py-3 text-sm">
                                    {{ optional($special->student->userprofile)->firstname }}
                                    {{ optional($special->student->userprofile)->lastname }}
                                </td>
                                <td class="px-6 py-3 text-sm">{{ $special->feeCategory->name }}</td>
                                <td class="px-6 py-3 text-sm font-semibold">₹{{ number_format($special->amount, 2) }}</td>
                                <td class="px-6 py-3 text-sm">
                                    @if ($special->due_date)
                                        {{ $special->due_date->format('M d, Y') }}
                                    @else
                                        <span class="text-gray-400">-</span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="px-6 py-4 text-center text-gray-500">No recent special fees</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="mt-8">
        <h3 class="text-lg font-bold text-gray-800 mb-4">Quick Actions</h3>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <a href="{{ route('finance.fee-categories.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition">
                ➕ New Category
            </a>
            <a href="{{ route('finance.fee-structures.create') }}" class="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-lg transition">
                📊 New Structure
            </a>
            <a href="{{ route('finance.special-fees.create') }}" class="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-4 rounded-lg transition">
                ⚡ Assign Special Fee
            </a>
            <a href="{{ route('finance.fee-management.export') }}" class="bg-gray-600 hover:bg-gray-700 text-white font-semibold py-3 px-4 rounded-lg transition">
                📥 Export Report
            </a>
        </div>
    </div>

</div>

@endsection
