@extends('layouts.admin.layout')

@section('title', 'Fee Payments Management')

@section('content')

<div class="max-w-6xl mx-auto px-4 py-6">

    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Fee Payments</h1>
        <p class="text-gray-600">Track and manage all fee payments</p>
    </div>

    <!-- Navigation Tabs -->
    <div class="mb-6 border-b border-gray-200">
        <div class="flex flex-wrap gap-4">
            <a href="{{ route('finance.fee-management.index') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Dashboard</a>
            <a href="{{ route('finance.fee-management.categories') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Categories</a>
            <a href="{{ route('finance.fee-management.structures') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Structures</a>
            <a href="{{ route('finance.fee-management.special-fees') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Special Fees</a>
            <a href="{{ route('finance.fee-management.payments') }}" class="px-4 py-3 border-b-2 border-blue-600 text-blue-600 font-semibold">Payments</a>
            <a href="{{ route('finance.fee-management.analytics') }}" class="px-4 py-3 border-b-2 border-transparent text-gray-600 hover:text-blue-600 hover:border-blue-600">Analytics</a>
        </div>
    </div>

    <!-- Search and Filter -->
    <div class="mb-6 bg-white rounded-lg shadow-md p-4">
        <form method="GET" action="{{ route('finance.fee-management.payments') }}" class="flex gap-4 flex-wrap">
            <input
                type="text"
                name="search"
                placeholder="Search by invoice no or student name..."
                value="{{ request('search') }}"
                class="flex-1 min-w-64 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
            <select name="status" class="border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">All Status</option>
                <option value="paid" {{ request('status') === 'paid' ? 'selected' : '' }}>Paid</option>
                <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Pending</option>
            </select>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition">
                🔍 Search
            </button>
        </form>
    </div>

    <!-- Payments Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Invoice No</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Student</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Class</th>
                        <th class="px-6 py-4 text-right text-sm font-semibold text-gray-700">Amount</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Payment Status</th>
                        <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Date</th>
                        <th class="px-6 py-4 text-center text-sm font-semibold text-gray-700">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($fees as $fee)
                        <tr class="border-t hover:bg-gray-50 transition">
                            <td class="px-6 py-4 text-sm font-semibold text-blue-600">{{ $fee->invoice_no }}</td>
                            <td class="px-6 py-4 text-sm">
                                <div class="font-semibold text-gray-800">
                                    {{ optional($fee->student->userprofile)->firstname }}
                                    {{ optional($fee->student->userprofile)->lastname }}
                                </div>
                                <div class="text-gray-500 text-xs">{{ optional($fee->student)->roll_number ?? 'N/A' }}</div>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-700">
                                {{ optional(optional($fee->studentAcademic)->standardLink->standard)->name }}
                                {{ optional(optional($fee->studentAcademic)->standardLink->section)->name }}
                            </td>
                            <td class="px-6 py-4 text-right text-sm font-semibold text-gray-800">₹{{ number_format($fee->total_amount, 2) }}</td>
                            <td class="px-6 py-4 text-sm">
                                @php
                                    $isPaid = $fee->balance == 0 || $fee->paid_amount >= $fee->total_amount;
                                    $status = $isPaid ? 'Paid' : 'Pending';
                                @endphp
                                <span class="px-3 py-1 rounded-full text-xs font-semibold {{ $isPaid ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800' }}">
                                    {{ $status }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-600">{{ $fee->created_at->format('M d, Y') }}</td>
                            <td class="px-6 py-4 text-center">
                                <a href="{{ route('finance.payments.create', $fee->id) }}" class="text-blue-600 hover:text-blue-800 font-semibold text-sm">Record Payment</a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-6 py-8 text-center text-gray-500">
                                <p class="text-lg">No payments found</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        {{ $fees->links() }}
    </div>

</div>

@endsection
