@extends('layouts.admin.layout')

@section('content')

<div>

    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">

        <div>

            <h1 class="admin-h1 font-plex my-3">
                Teacher Login Credentials
            </h1>

            <p class="text-gray-500">
                School admins can reset or generate teacher passwords.
            </p>

        </div>

        {{-- SEARCH BAR --}}
        <div class="mt-3 lg:mt-0">

            <input
                type="text"
                id="teacherSearch"
                placeholder="Search by teacher name or email..."
                class="border border-gray-300 rounded px-4 py-2 w-full lg:w-80 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >

        </div>

    </div>

    @include('partials.message')

    <div class="bg-white custom-shadow border overflow-x-auto">

        <table class="w-full" id="teacherTable">

            <thead>

                <tr class="border-b bg-gray-50">

                    <th class="text-left py-3 px-4">
                        Teacher
                    </th>

                    <th class="text-left py-3 px-4">
                        Login Email
                    </th>

                    <th class="text-left py-3 px-4">
                        New Password
                    </th>

                    <th class="text-left py-3 px-4">
                        Action
                    </th>

                </tr>

            </thead>

            <tbody id="teacherTableBody">

                @foreach($teachers as $teacher)

                    <tr class="border-b hover:bg-gray-50 teacher-row">

                        {{-- TEACHER NAME --}}
                        <td class="py-3 px-4 teacher-name">

                            {{ optional($teacher->userprofile)->firstname }}
                            {{ optional($teacher->userprofile)->lastname }}

                        </td>

                        {{-- EMAIL --}}
                        <td class="py-3 px-4 teacher-email">

                            {{ $teacher->email }}

                        </td>

                        {{-- RESET PASSWORD --}}
                        <td class="py-3 px-4">

                            <form
                                method="POST"
                                action="{{ url('/admin/teacher-credentials/'.$teacher->id.'/reset') }}"
                                class="flex gap-2"
                            >

                                @csrf

                                <input
                                    name="password"
                                    placeholder="Leave blank to auto-generate"
                                    class="border px-3 py-2 w-64 rounded"
                                >

                                <button
                                    class="bg-red-700 hover:bg-red-800 text-white px-3 py-2 rounded transition"
                                >

                                    Reset

                                </button>

                            </form>

                        </td>

                        {{-- PROFILE --}}
                        <td class="py-3 px-4">

                            <a
                                class="text-blue-600 hover:text-blue-800 font-medium"
                                href="{{ url('/admin/teacher/show/'.$teacher->name) }}"
                            >

                                Profile

                            </a>

                        </td>

                    </tr>

                @endforeach

            </tbody>

        </table>

        {{-- NO RESULTS --}}
        <div
            id="noResults"
            class="hidden text-center py-6 text-gray-500"
        >

            No teachers found.

        </div>

    </div>

    {{-- PAGINATION --}}
    <div class="mt-4">

        {{ $teachers->links() }}

    </div>

</div>

{{-- SEARCH SCRIPT --}}
<script>

document.addEventListener('DOMContentLoaded', function () {

    const searchInput =
        document.getElementById('teacherSearch');

    const rows =
        document.querySelectorAll('.teacher-row');

    const noResults =
        document.getElementById('noResults');

    searchInput.addEventListener('keyup', function () {

        let searchValue =
            this.value.toLowerCase().trim();

        let visibleRows = 0;

        rows.forEach(function (row) {

            let teacherName =
                row.querySelector('.teacher-name')
                    .innerText
                    .toLowerCase();

            let teacherEmail =
                row.querySelector('.teacher-email')
                    .innerText
                    .toLowerCase();

            if (
                teacherName.includes(searchValue)
                ||
                teacherEmail.includes(searchValue)
            ) {

                row.style.display = '';

                visibleRows++;

            } else {

                row.style.display = 'none';

            }

        });

        /*
        |--------------------------------------------------------------------------
        | No Results
        |--------------------------------------------------------------------------
        */

        if (visibleRows === 0) {

            noResults.classList.remove('hidden');

        } else {

            noResults.classList.add('hidden');

        }

    });

});

</script>

@endsection
